/*
 * SPI testing utility (using spidev driver)
 *
 * Copyright (c) 2007  MontaVista Software, Inc.
 * Copyright (c) 2007  Anton Vorontsov <avorontsov@ru.mvista.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License.
 *
 * Cross-compile with cross-gcc -I/path/to/cross-kernel/include
 */

#include <stdint.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>

#include <string.h>
#include "spi.h"
#include "rc_op.h"
#include "rc_base.h"




static void parse_opts(int argc, char *argv[])
{
	while (1) {
		static const struct option lopts[] = {
			{ "device",  1, 0, 'D' },
			{ "speed",   1, 0, 's' },
			{ "delay",   1, 0, 'd' },
			{ "bpw",     1, 0, 'b' },
			{ "loop",    0, 0, 'l' },
			{ "cpha",    0, 0, 'H' },
			{ "cpol",    0, 0, 'O' },
			{ "lsb",     0, 0, 'L' },
			{ "cs-high", 0, 0, 'C' },
			{ "3wire",   0, 0, '3' },
			{ "no-cs",   0, 0, 'N' },
			{ "ready",   0, 0, 'R' },
			{ NULL, 0, 0, 0 },
		};
		int c;

		c = getopt_long(argc, argv, "D:s:d:b:lHOLC3NR", lopts, NULL);

		if (c == -1)
			break;
/*
		switch (c) {
		case 'D':
			device = optarg;
			break;
		case 's':
			speed = atoi(optarg);
			break;
		case 'd':
			delay = atoi(optarg);
			break;
		case 'b':
			bits = atoi(optarg);
			break;
		case 'l':
			mode |= SPI_LOOP;
			break;
		case 'H':
			mode |= SPI_CPHA;
			break;
		case 'O':
			mode |= SPI_CPOL;
			break;
		case 'L':
			mode |= SPI_LSB_FIRST;
			break;
		case 'C':
			mode |= SPI_CS_HIGH;
			break;
		case '3':
			mode |= SPI_3WIRE;
			break;
		case 'N':
			mode |= SPI_NO_CS;
			break;
		case 'R':
			mode |= SPI_READY;
			break;
		default:
			break;
		}
	*/
	}
}

int main(int argc, char *argv[])
{
	int ret = 0;
	//int fd;

	//parse_opts(argc, argv);

	//fd = open(device, O_RDWR);
	//if (fd < 0)
	//	pabort("can't open device");
	//transfer(fd_531,ret);

  //spi_init();
  

	//spi_send_byte(0x5A);
	//spi_rece_byte();
		
		//rc_init0();
		rc_init();
    rc_select_op_type(ISO14443A_M1_TYPE);
    rc_power_on();

    
	//spi_close();
	uint8_t buf[5];
	uint8_t i,t;

//	for(t=0;t<3;t++){
/*		for(i=0;i<100;i++){	
	   if(rc_request(PICC_REQALL,buf) == 0){
	   	  printf("have card %d ", i);	
	    }
	     printf("try  %d ", i);	
	  }*/
//	}

  i=0;
  while(1){
	   if(rc_request(PICC_REQALL,buf) == 0){
	   	  printf("==========================have card %d --%02x%02x,", i,buf[0],buf[1]);	
	   	  usleep(1000000);
	    }
	    usleep(100000);
	    rc_power_off();
	     printf("try  %d ", i++);	
  }
}