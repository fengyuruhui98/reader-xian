#ifndef _MIFARE_C_
#define _MIFARE_C_
//start of file

#include "global.h"




//ֵ����������
//uint8_t  bgEm681ValueOperateMode;
//uint8_t  bgEm681ValueBlock;
//UDWORD dwgEm681Value;

//#define _mifare_debug_

/*=======================================================================
��������mcml_request:
��  �ܣ�
=========================================================================*/
uint8_t mcml_request(uint8_t req_code,uint8_t *atq)
{
uint8_t i;	
for(i=0;i<3;i++){	
   if(rc_request(req_code,atq) == 0) return 0;	
    }
return (uint8_t)-1;
}


/*=========================================================================
��������mcml_anticoll
��  �ܣ�����ײ���
��ڲ���: SNR:5�ֽڿ����к�ָ�룬���һ�ֽ�ΪУ���ֽ�
���ڲ���:
  0����ȷ
 ���ࣺ����
==========================================================================*/
uint8_t mcml_anticoll(uint8_t *snr)
{
uint8_t ret;
ret = rc_anticoll(PICC_ANTICOLL1,0,snr);       
return ret;
}

uint8_t mcml_anticoll2(uint8_t *snr)
{
uint8_t ret;
ret = rc_anticoll(PICC_ANTICOLL2,0,snr);       
return ret;
}


/*==========================================================================
��������mcml_select
��  �ܣ�ѡ��ָ�����кŵĿ�
��ڲ���:
	SNR: �����к��ַ���ָ��
	cardsize:���صĿ�������ʶָ��
���ڲ���:
 0:��ȷ
-1:����
=============================================================================*/
uint8_t mcml_select(uint8_t *snr,uint8_t *status)
{
uint8_t ret,buf[2];	
//
ret = rc_select(PICC_ANTICOLL1,snr,buf);
status[0] = buf[0];
//if(ret==0){
	gThisCardSnr[0] = snr[0];
	gThisCardSnr[1] = snr[1];
	gThisCardSnr[2] = snr[2];
	gThisCardSnr[3] = snr[3];	
	gThisCardSnr[4] = snr[4];	
//	}
//
return ret;
}

uint8_t mcml_select2(uint8_t *snr,uint8_t *status)
{
uint8_t ret,buf[2];	
//
ret = rc_select(PICC_ANTICOLL2,snr,buf);
status[0] = buf[0];
//
return ret;
}


/*===========================================================================
��������mcml_load_key
��  �ܣ�
=============================================================================*/
uint8_t mcml_load_key(uint8_t keyset,uint8_t keyab, uint8_t sectno,uint8_t *buf)
{
keyab = keyab;
keyset=keyset;
sectno=sectno;
gRc500Key[0] = buf[0];
gRc500Key[1] = buf[1];
gRc500Key[2] = buf[2];
gRc500Key[3] = buf[3];
gRc500Key[4] = buf[4];
gRc500Key[5] = buf[5];
return 0;
}


/*==========================================================================
����:mcml_authentication:
����:��֤
============================================================================*/
uint8_t mcml_authentication(uint8_t keyset,uint8_t keyab,uint8_t sectno)
{
uint8_t ret;
	
keyset = keyset;
if(keyab == KEYA) keyab = PICC_AUTHENT1A;
else keyab = PICC_AUTHENT1B;

ret = rc_auth(keyab,sectno);
//
return (uint8_t)ret;
}

uint8_t mcml_authentication2(uint8_t keyset,uint8_t keyab,uint8_t sectno)
{
uint8_t ret;
	
keyset = keyset;
if(keyab == KEYA) keyab = PICC_AUTHENT1A;
else keyab = PICC_AUTHENT1B;

ret = rc_auth2(keyab,sectno);
//
return (uint8_t)ret;
}


/*==========================================================================
����:mcml_read
����:��һ����
============================================================================*/
uint8_t mcml_read(uint8_t block,uint8_t *outbuf)
{
	
if(rc_read(block,outbuf) == 0) return 0;
return (uint8_t)-1;
}

uint8_t mcml_read_4bytes(uint8_t block,uint8_t *outbuf)
{
#ifdef _mifare_debug_
printk("\nmcml_read_4bytes,block[%d]....",block);
#endif	
if(rc_read_4bytes(block,outbuf) == 0) return 0;
return (uint8_t)-1;
}


/*==========================================================================
������mcml_write
���ܣ�дһ����
============================================================================*/
uint8_t mcml_write(uint8_t block,uint8_t *inbuf)
{
if(rc_write(block,inbuf) == 0) return 0;
return (uint8_t)-1;
}

uint8_t mcml_write_4bytes(uint8_t block,uint8_t *inbuf)
{
#ifdef _mifare_debug_
printk("\nmcml_write_4bytes,block[%d]....",block);
#endif	
if(rc_write_4bytes(block,inbuf) == 0) return 0;
return (uint8_t)-1;
}

/*===========================================================================
������mcml_increment
���ܣ�����һ��ֵ
=============================================================================*/
uint8_t mcml_increment(uint8_t addr, uint32_t value)
{
uint8_t buf[4];

//bgEm681ValueOperateMode = PICC_INCREMENT;
//dwgEm681Value = value;
//bgEm681ValueBlock = addr;
//return 0;	

udword_to_buf_reverse(value,buf);
return rc_value_op0(PICC_INCREMENT,addr,buf);
}

/*============================================================================
������mcml_decrement
���ܣ�����һ��ֵ
==============================================================================*/
uint8_t mcml_decrement(uint8_t addr,uint32_t value)
{
uint8_t buf[4];
	
//bgEm681ValueOperateMode = PICC_DECREMENT;
//dwgEm681Value = value;
//bgEm681ValueBlock = addr;
//return 0;	
udword_to_buf_reverse(value,buf);
return rc_value_op0(PICC_DECREMENT,addr,buf);
}

/*====================================================================================================
������mcml_transfer
���ܣ�ʵ��д��������
=====================================================================================================*/
uint8_t mcml_transfer(uint8_t addr)
{
//uint8_t value[4];
//
//switch(bgEm681ValueOperateMode){
//	case PICC_RESTORE:
//	case PICC_DECREMENT:
//	case PICC_INCREMENT:
//		   break;
//	default:
//		   return 1;	   		
//	}
//value[0] = *((char *)&dwgEm681Value+LONG_HIGH0);
//value[1] = *((char *)&dwgEm681Value+LONG_HIGH1);
//value[2] = *((char *)&dwgEm681Value+LONG_HIGH2);
//value[3] = *((char *)&dwgEm681Value+LONG_HIGH3);
////	
//return rc_value_op(bgEm681ValueOperateMode,bgEm681ValueBlock,value,addr);
return rc_transfer(addr);
}

/*==================================================================================================
������mcml_restore
���ܣ�
====================================================================================================*/
uint8_t mcml_restore(uint8_t addr)
{
//bgEm681ValueOperateMode = PICC_RESTORE;
//bgEm681ValueBlock = addr;
//return 0;	
uint8_t value[4];

memset(value,0,4);
return rc_value_op0(PICC_RESTORE,addr,value);
}


/*==================================================================================================
������mcml_pwr_off
���ܣ�
====================================================================================================*/
void mcml_pwr_off(void)
{
rc_power_off();
return;
}

/*==================================================================================================
������mcml_halt
���ܣ�
====================================================================================================*/
uint8_t mcml_halt(void)
{
return rc_halta();
}

//end of file
#endif
