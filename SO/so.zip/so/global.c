#ifndef _GLOBAL_C_
#define _GLOBAL_C_
//start of file

#include "global.h"

unsigned char bgLibInUseFlag = 0;
//RF
unsigned char blnRFUseFlag = 0;
int  igLibFd;         
//EEPROM file
unsigned char EEPROM[8192];
unsigned char bgEEInUseFlag = 0xff;
FILE	*flEEprom;
//EEPROM system 
static const char *eeprom = "/sys/bus/i2c/devices/2-0050/eeprom";
int		fdEEprom;

//LED
FILE	*flLEDRed, *flLEDGreen;
unsigned char blnLEDRedUseFlag = 0xff, blnLEDGreenUseFlag = 0xff;
static const char *redled = "/sys/bus/platform/devices/leds-gpio/leds/red/brightness";
static const char *greenled = "/sys/bus/platform/devices/leds-gpio/leds/green/brightness";
static const char *ledon ="1";
static const char *ledoff ="0";


const char *
rfid_hexdump(const void *data, unsigned int len)
{
	static char string[1024];
	unsigned char *d = (unsigned char *) data;
	unsigned int i, left;

	string[0] = '\0';
	left = sizeof(string);
	for (i = 0; len--; i += 3) {
		if (i >= sizeof(string) -4)
			break;
		snprintf(string+i, 4, " %02x", *d++);
	}
	return string;
}


void delay_ms(int cnt)//???????????
{
	usleep(1000*cnt);
}

void delay_us(int cnt)//???????????
{
	usleep(cnt);
}

void ms_delay(int cnt)//???????????
{
	usleep(1000*cnt);
}

void us_delay(int cnt)//???????????
{
	usleep(cnt); 
}

UBYTE InitModule(void)
{
	if(bgLibInUseFlag) return 0;  //�Ѿ�����
	//	
	uart_init();
	//uart_open(2,115200);
	uart_open(SAM_UART_INDEX, 460800);
	//linux_sam_init();
	#ifdef DEBUG_LINUX2440
		printf("Device %s open ok.\n",DEV_NAME);
	#endif
	bgLibInUseFlag = 0xff;
	return 0;	
}

/*==============================================================================
������
���ܣ�
================================================================================*/
UBYTE CleanUpModule(void)
{
	if(!bgLibInUseFlag)	return 0; 

	close(igLibFd);
	bgLibInUseFlag = 0;

	return 0;
}


UBYTE rf_reset(void)
{
	return 0;
}

void set_card_type(UBYTE card_type)
{
UBYTE	ret;

	ret = rc_select_op_type(card_type);
	
	return ;
}

UBYTE UL_Anticoll_Select(UBYTE * psnr)
{
UBYTE	ret;
UBYTE cardsnr1[5],cardsnr2[5], buf[5];

	ret = mcml_anticoll(cardsnr1);
	if(ret) return -1;
	
	ret = mcml_select(cardsnr1, buf);
	if(ret) return -1;
	
	ret = mcml_anticoll2(cardsnr2);
	if(ret) return -1;
		
	ret = mcml_select2(cardsnr2, buf);
	if(ret) return -1;
	
	memcpy(psnr, &cardsnr1[1], 3);
	memcpy(&psnr[3], cardsnr2, 4);
	
	return 0;
}

UBYTE UL_Page_Read(UBYTE addr, UBYTE *pReaddata)
{
UBYTE	oBuf[20], ret;

	ret = mcml_read(addr, oBuf);
	memcpy(pReaddata, oBuf, 4);
	
	return ret;
}

UBYTE UL_Page_Write(UBYTE addr, UBYTE *pWritedata)
{
UBYTE	iBuf[20], ret;

	memset(iBuf, 0x00, sizeof(iBuf));
	memcpy(iBuf, pWritedata, 4);

	return mcml_write(addr, iBuf);
}

UBYTE mcml_request2(UBYTE request_type,UBYTE * atq)
{
	if( !blnRFUseFlag )
	{
		rc_init();
		blnRFUseFlag = 0xff;
	}
	return mcml_request(request_type, atq);
}

UWORD rtc_rd_time(UBYTE *outbuf)
{
time_t lnglocaltime;
struct tm *tplocaltime;
long year;
unsigned char datTime;

	time(&lnglocaltime);
	tplocaltime = localtime(&lnglocaltime);

	year = tplocaltime->tm_year + 1900;
	
	outbuf[0] = (unsigned char)(year-2000);
	outbuf[0] = (outbuf[0]/10)*16 + (outbuf[0]%10);
	
	outbuf[1] = tplocaltime->tm_mon+1;
	outbuf[1] = (outbuf[1]/10)*16 + (outbuf[1]%10);
	
	outbuf[2] = tplocaltime->tm_mday;
	outbuf[2] = (outbuf[2]/10)*16 + (outbuf[2]%10);
	
	outbuf[3] = tplocaltime->tm_hour;
	outbuf[3] = (outbuf[3]/10)*16 + (outbuf[3]%10);
	
	outbuf[4] = tplocaltime->tm_min;
	outbuf[4] = (outbuf[4]/10)*16 + (outbuf[4]%10);
	
	outbuf[5] = tplocaltime->tm_sec;
	outbuf[5] = (outbuf[5]/10)*16 + (outbuf[5]%10);
	
#ifdef	DEBUG_HARDWARE
	printf("date %02x-%02x-%02x %02x:%02x:%02x\n", outbuf[0], outbuf[1], outbuf[2], outbuf[3], outbuf[4], outbuf[5]);
#endif

	return 0;
}

UWORD rtc_wr_time(UBYTE *inbuf)
{
struct timeval tv;
struct tm tplocaltime;
long year;

	tplocaltime.tm_year = (((inbuf[0]/16)*10) + (inbuf[0]%16)) + 2000 - 1900;

	tplocaltime.tm_mon = ((inbuf[1]/16)*10) + (inbuf[1]%16) - 1;

	tplocaltime.tm_mday = ((inbuf[2]/16)*10) + (inbuf[2]%16);

	tplocaltime.tm_hour = ((inbuf[3]/16)*10) + (inbuf[3]%16);

	tplocaltime.tm_min = ((inbuf[4]/16)*10) + (inbuf[4]%16);
	
	tplocaltime.tm_sec = ((inbuf[5]/16)*10) + (inbuf[5]%16);
	
	tv.tv_sec = mktime(&tplocaltime);
	tv.tv_usec = 0;
	
	settimeofday(&tv, NULL);
	
	return 0;
}

UWORD ee_read(UWORD addr,UWORD bytes,UBYTE *outbuf)
{
	InitModule();
	if(bgEEInUseFlag)
	{
		//flEEprom = fopen("./eeprom", "wb+");
		//if(flEEprom == NULL)
		//	return 0xff;
		
		fdEEprom = open(eeprom, O_RDWR);
		if( fdEEprom < 0)
			return 0xff;
			
		bgEEInUseFlag = 0;
		//fread(EEPROM, sizeof(EEPROM), 1, flEEprom);
		read(fdEEprom, EEPROM, sizeof(EEPROM));
	}
	memcpy(outbuf, &EEPROM[addr], bytes);

	return 0;
}

UWORD ee_write(UWORD addr,UWORD bytes,UBYTE *inbuf)
{
	InitModule();
	if(bgEEInUseFlag)
	{
		//flEEprom = fopen("./eeprom", "wb+");
		//if(flEEprom == NULL)
		//	return 0xff;
		
		fdEEprom = open(eeprom, O_RDWR);
		if(fdEEprom < 0)
			return 0xff;
			
		bgEEInUseFlag = 0;
		//fread(EEPROM, sizeof(EEPROM), 1, flEEprom);
		read(fdEEprom, EEPROM, sizeof(EEPROM));
	}
	memcpy(&EEPROM[addr], inbuf, bytes);
//	if(flEEprom != NULL)
//	{
//		fseek(flEEprom, addr, SEEK_SET);
//		fwrite(&EEPROM[addr], bytes, 1, flEEprom);
//	}
	if( fdEEprom > 0)
	{
		lseek(fdEEprom, addr, SEEK_SET);
		write(fdEEprom, &EEPROM[addr], bytes);
	}
	return 0;
}

UWORD watchdog_init(UBYTE type, UBYTE timeout)
{
	return 0;
}

UWORD watchdog(void)
{
	return 0;
}

UBYTE reader_get_version(UBYTE *version, UBYTE *len)
{
	return 0;
}

void rled(UBYTE option)
{
	if( blnLEDRedUseFlag )
	{
		if( NULL == (flLEDRed = fopen(redled, "rb+")) )
		{
			return ;
		}
		blnLEDRedUseFlag = 0;
	}

	if( flLEDRed != NULL )
	{
		if(option == LED_ON)
			fwrite(ledon, sizeof(char), 1, flLEDRed);
		else
			fwrite(ledoff, sizeof(char), 1, flLEDRed);
	}
	return ;
}


void gled(UBYTE option)
{
	if( blnLEDGreenUseFlag )
	{
		if( NULL == (flLEDGreen = fopen(redled, "rb+")) )
		{
			return ;
		}
		blnLEDGreenUseFlag = 0;
	}

	if( flLEDGreen != NULL )
	{
		if(option == LED_ON)
			fwrite(ledon, sizeof(char), 1, flLEDGreen);
		else
			fwrite(ledoff, sizeof(char), 1, flLEDGreen);
	}
	return ;
}

void rgled(UBYTE option)
{
	if( blnLEDRedUseFlag )
	{
		if( NULL == (flLEDRed = fopen(redled, "rb+")) )
		{
			return ;
		}
		blnLEDRedUseFlag = 0;
	}
	if( blnLEDGreenUseFlag )
	{
		if( NULL == (flLEDGreen = fopen(redled, "rb+")) )
		{
			return ;
		}
		blnLEDGreenUseFlag = 0;
	}
	if( flLEDRed != NULL )
	{
		if(option == LED_ON)
			fwrite(ledon, sizeof(char), 1, flLEDRed);
		else
			fwrite(ledoff, sizeof(char), 1, flLEDRed);
	}
	
	if( flLEDGreen != NULL )
	{
		if(option == LED_ON)
			fwrite(ledon, sizeof(char), 1, flLEDGreen);
		else
			fwrite(ledoff, sizeof(char), 1, flLEDGreen);
	}

	return ;
}

UBYTE mifpro_ats(UBYTE in_cid,UBYTE *outbuf,UBYTE *outbytes)
{
UWORD	obytes;
UWORD	ret;
	
	ret = _mifpro_ats(in_cid, outbuf, &obytes);
	
	*outbytes = (UBYTE)obytes;
	
	return (UBYTE)ret;
}

UBYTE mifpro_icmd(UBYTE *inbuf,UBYTE inbytes,UBYTE *outbuf,UBYTE *outbytes)
{
UBYTE	ret;
UWORD	obytes;

	ret = _mifpro_icmd(inbuf, inbytes, outbuf, &obytes);
	*outbytes = obytes;
	return ret;	
}


#endif