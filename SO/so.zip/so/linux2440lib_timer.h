//timer.h

#ifndef _TIMER_H_
#define _TIMER_H_
//start of file

#include <sys/time.h>

#define TIMER_CMD_PROCESS_INDEX   0           //����ִ��ʱ��      
#define TIMER_SAM_SEND_INDEX      1            //SAMģ��Э�鷢�Ͷ�ʱ�� 
#define TIMER_SAM_RECE_INDEX      2            //SAMģ��Э����ն�ʱ��


#define MAX_TIMER_INDEX           128

extern UDWORD dwgTimerCnt[MAX_TIMER_INDEX];

void timer_set(UBYTE index,UWORD limit);
UBYTE timer_check(UBYTE index);
void timer_clr(UBYTE index);
UDWORD timer_get(UBYTE index);

//end of file
#endif



